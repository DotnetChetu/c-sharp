﻿using MyCSApp.models;
using MyCSApp.partial;
using System;
using System.Collections.Generic;
using System.Threading;
namespace MyCSApp
{
    class Program
    {
        public delegate void MyDelegate(int a, int b);
        static void Main(string[] args)
        {

            //MyDelegate obj = new MyDelegate(Addition);
            //obj += Substract;
            //obj += Product;
            //obj.Invoke(35,10);
            //// unregister method
            //Console.WriteLine("------------------------------\n");
            //obj -= Substract;
            //obj.Invoke(100, 30);
            Console.WriteLine("-----Main method started---");
            Thread t1 = new Thread(Task1);
            Thread t2 = new Thread(Task2);
            Thread t3 = new Thread(Task3);
            t1.Start(); t2.Start();t3.Start();
            t1.Join(); t2.Join(); t3.Join();

            Console.WriteLine("-----Main method ended---");


            Console.ReadKey();
        }



        public static void Task1()
        {
            Console.WriteLine("----Task-1 started----");
            for(int i=1; i<=10; i++)
            {
                if (i == 5)
                {
                    Thread.Sleep(5000);
                }
                Console.WriteLine("Task-1 : "+i);
            }
            Console.WriteLine("---------Task-1 ended-----");
        }

        public static void Task2()
        {
            Console.WriteLine("----Task-2 started----");
            for (int i = 1; i <= 10; i++)
            {
                Console.WriteLine("Task-2 : " + i);
            }
            Console.WriteLine("---------Task-2 ended-----");
        }
        public static void Task3()
        {
            Console.WriteLine("----Task-3 started----");
            for (int i = 1; i <= 10; i++)
            {
                Console.WriteLine("Task-3 : " + i);
            }
            Console.WriteLine("---------Task-3 ended-----");
        }
        public static void Addition(int x , int y)
        {
            Console.WriteLine("I am test Method !");
            Console.WriteLine("Addition : "+(x+y));
        }

        public static void Substract(int x, int y)
        {
            Console.WriteLine("I am test Method !");
            Console.WriteLine("Substraction : " + (x - y));
        }

        public static void Product(int x, int y)
        {
            Console.WriteLine("I am test Method !");
            Console.WriteLine("Multiplication : " + (x * y));
        }

        public static int Calc(int x, int y, out int m, out int d)
        {
            int r = x + y;
            m = x * y;
            d = x - y;
            return r;
        }

        public static int Addition(params int []arr)
        {
            int z = 0;
            foreach (int i in arr)
                z += i;
            return z;
        }
      
        public static void CallByRef(ref int x, ref int y)
        {
            x += 10;
            y += 50;
            Console.WriteLine("Inside x: "+x);
            Console.WriteLine("Inside y: "+y);

        }
        public static void CallByValue(int x, int y)
        {
            x += 10;
            y += 50;
            Console.WriteLine("Inside x: " + x);
            Console.WriteLine("Inside y: " + y);

        }
        public static void ValidateUrl()
        {
            string url = "https://www.facebook.com";
            Console.WriteLine(url.StartsWith("https://"));
            if((url.StartsWith("https://") || url.StartsWith("https://")) && (url.EndsWith(".com")|| url.EndsWith(".org")))
            {
                Console.WriteLine("Valid url");
            }
            else
            {
                Console.WriteLine("Invalid url");
            }
        }
    }
}
