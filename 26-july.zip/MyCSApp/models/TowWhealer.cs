﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyCSApp.models
{
    class TowWhealer:Vehicle
    {
        public override void Move()
        {
            Console.WriteLine("Tow whealer vehivcle moving...");
        }
    }
}
