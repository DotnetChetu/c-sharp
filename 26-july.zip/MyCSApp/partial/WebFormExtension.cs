﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyCSApp.partial
{
   static class WebFormExtension
    {
        public static void FillColor(this WebForm form)
        {
            Console.WriteLine("Just i am extesion method !");
        }
    }
}
