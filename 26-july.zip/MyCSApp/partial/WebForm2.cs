﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyCSApp.partial
{
   partial class WebForm
    {
        public void Button()
        {
            Console.WriteLine("Button created----");
        }
        public void TextBox()
        {
            Console.WriteLine("TextBox created----");
        }

    }
}
