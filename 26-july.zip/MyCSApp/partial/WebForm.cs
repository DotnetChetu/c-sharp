﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyCSApp.partial
{
   public partial class WebForm
    {

        public void Frame()
        {
            Console.WriteLine("Frame created ----");
        }
    }
}
