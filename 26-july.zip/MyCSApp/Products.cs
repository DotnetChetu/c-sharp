﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyCSApp
{
   static class Products
    {
        static Products()
        {
            Console.WriteLine("I am static constructor ");

        }

        public static void Test()
        {
            Console.WriteLine("I am static method !");
        }

    }
}
