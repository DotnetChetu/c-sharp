﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyCSApp
{
    class MyStatic
    {
        public static int count;
        public MyStatic()
        {
            count += 1;
        }
    }
}
